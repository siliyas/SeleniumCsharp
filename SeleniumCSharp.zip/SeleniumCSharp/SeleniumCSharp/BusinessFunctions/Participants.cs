using System;
using System.IO;
using NUnit.Framework;
using SeleniumCSharp.PageObject;
using SeleniumCSharp.XmlUtil;

namespace SeleniumCSharp
{
	public class Tests
	{
		UA_AddParticipatns participantsObject = new UA_AddParticipatns();
		[Test]
		public void AddParticipants()
		{
			string path = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;
			path =  path + @"\Data\UserData.xml";
            UserData UserDataObj = (UserData)XmlToObject.ReadUserData(path);
            participantsObject.LaunchApplication(UserDataObj.URL);
			participantsObject.Login(UserDataObj.InvaliUserName, UserDataObj.InvalidPassword, UserDataObj.LoginButton);
			participantsObject.VerifyNotification(UserDataObj.FailureNotification);
			participantsObject.ClickRequestNewUser();			
			participantsObject.Login(UserDataObj.RandomEmail,string.Empty,"E-mail new password");
			participantsObject.VerifyNotification(UserDataObj.InstructionNotification);
			participantsObject.Login(UserDataObj.UserName, UserDataObj.Password, UserDataObj.LoginButton);
			participantsObject.SelectUser(UserDataObj.People, UserDataObj.Users);
			participantsObject.ClickHyperlink("Import Participants");
			participantsObject.BrowseFile(UserDataObj.ImportFile);
			participantsObject.ClickButton("Import");		
		}
	}
}