﻿using System;
using System.IO;
using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Support.UI;

namespace SeleniumCSharp.PageObject
{
    class SA_AddParticipatnsActions
    {
		IWebDriver driver;
		string UsernameText = "edit-name";
		string PasswordText = "edit-pass";
		string CommonUIButton = "//button[text()='{0}']";
		string CommonHyperLink = "//a[contains(text(),'{0}')]";
		string BrowserFile = "//input[@type='file']";
		string NotificationAlert = "//div[contains(@class, 'alert-block ')]";
		string RequestNewUserLink = "//a[@href='/home/406121/user/password']";

		public SA_AddParticipatnsActions()
		{
			string path = Directory.GetParent(Environment.CurrentDirectory).Parent.Parent.FullName;
			driver = new ChromeDriver(path + @"\drivers\");
		}
		public void GetURL(string URL) => driver.Navigate().GoToUrl(URL);		
		public void MaximumWindow() => driver.Manage().Window.Maximize();		
		public void EnterUserName(string Username) => driver.FindElement(By.Id(UsernameText)).SendKeys(Username);        
		public void EnterPassword(string Password) => driver.FindElement(By.Id(PasswordText)).SendKeys(Password);
		public void ClickButton(string ButtonName) => driver.FindElement(By.XPath(string.Format(CommonUIButton, ButtonName))).Click();
		public void ClickRequestNewUser() => driver.FindElement(By.XPath(RequestNewUserLink)).Click();
		public void ClickHyperlink(string LinkName) => driver.FindElement(By.XPath(string.Format(CommonHyperLink, LinkName))).Click();
		public void BrowseFile(string FilePath) => driver.FindElement(By.XPath(BrowserFile)).SendKeys(FilePath);
		public void VerifyNotification(string ExpectedNotificationText)
		{
            WebDriverWait wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            wait.Until(SeleniumExtras.WaitHelpers.ExpectedConditions.ElementIsVisible(By.XPath(NotificationAlert)));
            Assert.IsTrue(driver.FindElement(By.XPath(NotificationAlert)).Text.Contains(ExpectedNotificationText));
        }
	}
}
