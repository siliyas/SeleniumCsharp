﻿using System.IO;
using System.Xml.Serialization;

namespace SeleniumCSharp.XmlUtil
{
    class XmlToObject
    {
        public static object ReadUserData(string XMLFileName)
        {
            XmlRootAttribute xRoot = new XmlRootAttribute();
            xRoot.ElementName = "UserData";
            xRoot.IsNullable = true;
            XmlSerializer deserializer = new XmlSerializer(typeof(UserData), xRoot);
            TextReader reader = new StreamReader(@XMLFileName);
            object obj = deserializer.Deserialize(reader);
            reader.Close();
            return obj;
        }
    }
}
