﻿namespace SeleniumCSharp.XmlUtil
{
    public class UserData
    {
        public string URL { get; set; }
        public string InvaliUserName { get; set; }
        public string InvalidPassword { get; set; }
        public string LoginButton { get; set; }
        public string FailureNotification { get; set; }
        public string RandomEmail { get; set; }
        public string RandomPassword { get; set; }
        public string InstructionNotification { get; set; }
        public string UserName { get; set; }
        public string Password { get; set; }
        public string Users { get; set; }
        public string People { get; set; }
        public string ImportFile { get; set; }
        public string CreatedNotification { get; set; }
    }
}
