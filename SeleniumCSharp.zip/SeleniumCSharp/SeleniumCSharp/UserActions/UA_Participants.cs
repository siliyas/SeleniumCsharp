using System.Runtime.InteropServices;

namespace SeleniumCSharp.PageObject
{
    class UA_AddParticipatns
    {
        SA_AddParticipatnsActions PageObject = new SA_AddParticipatnsActions();

        public void LaunchApplication(string URL)
        {
            PageObject.GetURL(URL);
            PageObject.MaximumWindow();
        }
        public void Login(string Username, [Optional] string Password, string ButtonName)
        {
            PageObject.EnterUserName(Username);
            if (!string.IsNullOrEmpty(Password))
            {
                PageObject.EnterPassword(Password);
            }
            PageObject.ClickButton(ButtonName);
        }
        public void ClickRequestNewUser()
        {
            PageObject.ClickRequestNewUser();
        }
        public void SelectUser(string People, string Users)
        {
            PageObject.ClickHyperlink(People);
            PageObject.ClickHyperlink(Users);
        }
        public void ClickHyperlink(string LinkName)
        {
            PageObject.ClickHyperlink(LinkName);
        }
        public void ClickButton(string ButtonName)
        {
            PageObject.ClickButton(ButtonName);
        }
        public void BrowseFile(string FilePath)
        {
            PageObject.BrowseFile(FilePath);
        }

        public void VerifyNotification(string ExpectedNotificationText)
        {
            PageObject.VerifyNotification(ExpectedNotificationText);
        }
    }
}
